package org.math.io;

import java.io.*;

/**
 * BSD License
 * 
 * @author Yann RICHET
 */
public interface FilePrintable {
    public void toASCIIFile(File f);
}