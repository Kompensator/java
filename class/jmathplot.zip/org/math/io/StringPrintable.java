package org.math.io;

/**
 * BSD License
 * 
 * @author Yann RICHET
 */
public interface StringPrintable {
    public String getText();
}